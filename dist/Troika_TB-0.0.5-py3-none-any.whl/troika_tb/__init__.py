
"""Troika_tb 
.. moduleauthor:: Kristy Horan <kristyhoran15@gmail.com>
"""
__author__ = "Kristy Horan"
__license__ = "GPL"
__maintainer__ = "Kristy Horan"
__email__ = "kristyhoran15@gmail.com"
__status__ = "Development"
__version__ = "0.0.3"
# db_version = "TBProfiler-20190820"